package com.example.todolist.to_do;

public interface ToDoView {

    void setInitialDate(int year, int month, int date);

}
