package com.example.todolist.old_task;

public interface OldTaskView {
}
