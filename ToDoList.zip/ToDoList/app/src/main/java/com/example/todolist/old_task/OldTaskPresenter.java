package com.example.todolist.old_task;

public class OldTaskPresenter {

    OldTaskView getView;

    public OldTaskPresenter(OldTaskView getView) {
        this.getView = getView;
    }



    void onStart() {

    }

}
